# Embedded Web Server (ESP32)

Intern ID: CT-1484